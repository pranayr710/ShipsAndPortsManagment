package Ships;

public interface PortOperations {
    void registerPort();
    void displayDetails();
    void manageContainers();
}
